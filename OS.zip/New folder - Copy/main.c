#include <stdio.h>                   // For input/output functions
#include <stdlib.h>                  // For malloc and free
#include <string.h>                  // For string manipulation
#include <stdbool.h>                 // For using boolean type

#define MAX_MEMORY 100               // Maximum number of objects allowed

typedef struct Object {
    char name[20];                  // Name of the object (max 19 chars + null terminator)
    bool marked;                    // Used to indicate if the object is reachable
    size_t size;                    // Size of the object
    struct Object* next;           // Pointer to another object (simulating reference)
} Object;

Object* memory[MAX_MEMORY];         // Array to store allocated object pointers
int allocated = 0;                  // Count of currently allocated objects
Object* root = NULL;                // Root object reference for GC
size_t total_allocated = 0, total_freed = 0; // Memory tracking

Object* gc_alloc(const char* name) {                        // Allocate a new object
    if (allocated >= MAX_MEMORY) {                         // If memory is full
        gc_collect();                                      // Run garbage collection
        if (allocated >= MAX_MEMORY) {                     // Check again after GC
            printf("\u274C Out of memory!\n");              // Print error
            return NULL;                                   // Return null if still full
        }
    }
    Object* obj = malloc(sizeof(Object));                  // Allocate memory for the object
    strncpy(obj->name, name, 19); obj->name[19] = '\0';    // Set object name and null-terminate
    obj->marked = false;                                   // Initialize as unmarked
    obj->size = sizeof(Object);                            // Set size
    obj->next = NULL;                                      // Initialize next pointer
    memory[allocated++] = obj;                             // Add to memory list and increment count
    total_allocated += obj->size;                          // Track total memory
    printf("\u2705 Created '%s'\n", obj->name);               // Print creation info
    return obj;                                            // Return pointer to object
}

void gc_add_reference(Object* from, Object* to) {          // Create reference from one object to another
    if (from && to) { from->next = to;                     // Set next if both objects exist
        printf("\ud83d\udd17 '%s'→'%s'\n", from->name, to->name); // Print reference
    }
}

void gc_mark(Object* obj) {                                // Mark phase of GC
    if (obj && !obj->marked) {                             // If object is not null and unmarked
        obj->marked = true;                                // Mark it
        printf("  \u2713 Marking '%s'\n", obj->name);         // Print mark info
        gc_mark(obj->next);                                // Recursively mark linked object
    }
}

void gc_sweep() {                                          // Sweep phase of GC
    int new_alloc = 0;                                     // New count after sweep
    for (int i = 0; i < allocated; i++) {                  // Loop through all allocated objects
        if (!memory[i]->marked) {                          // If object is not marked
            free(memory[i]);                               // Free the object
        } else {                                           // If marked
            memory[i]->marked = false;                     // Unmark for future GC
            memory[new_alloc++] = memory[i];               // Keep it in the memory list
        }
    }
    allocated = new_alloc;                                // Update allocation count
}

void gc_collect() {                                        // Trigger full GC cycle
    printf("\n\ud83d\udd0d GC Start\n");                  // Start GC message
    if (root) gc_mark(root);                               // Start marking from root
    gc_sweep();                                            // Sweep after marking
    printf("\u2705 GC Complete\n\n");                      // Print GC summary
}

void gc_print_status() {                                   // Show memory state
    printf("\n\ud83d\udcca Memory Status\nRoot: %s\nObjects: %d/%d\n",
           root ? root->name : "NULL", allocated, MAX_MEMORY); // Print status line
    for (int i = 0; i < allocated; i++)                    // Loop through all active objects
        printf("  %s → %s\n", memory[i]->name,
               memory[i]->next ? memory[i]->next->name : "NULL"); // Print each object and its link
}

int main() {
    printf("\ud83d\ude80 Garbage Collector v2.0\nCommands: create, link, setroot, collect, status, exit\n\n"); // Print welcome
    char cmd[20], n1[20], n2[20];                          // Buffers for commands
    while (printf("> "), scanf("%s", cmd), strcmp(cmd, "exit")) { // Read command loop
        if (!strcmp(cmd, "create") && scanf("%s", n1)) gc_alloc(n1); // Create object
        else if (!strcmp(cmd, "link") && scanf("%s %s", n1, n2)) {   // Link objects
            Object *from = NULL, *to = NULL;              // Temp pointers
            for (int i = 0; i < allocated; i++) {
                if (!from && !strcmp(memory[i]->name, n1)) from = memory[i]; // Find 'from' object
                if (!to && !strcmp(memory[i]->name, n2)) to = memory[i];     // Find 'to' object
            }
            from && to ? gc_add_reference(from, to) : printf("\u274C Objects missing\n"); // Add ref or error
        }
        else if (!strcmp(cmd, "setroot") && scanf("%s", n1)) {       // Set root object
            for (int i = 0; i < allocated; i++)
                if (!strcmp(memory[i]->name, n1)) { root = memory[i]; printf("\u2b50 Root set\n"); break; }
        }
        else if (!strcmp(cmd, "collect")) gc_collect();              // Manual GC
        else if (!strcmp(cmd, "status")) gc_print_status();          // Show status
        else printf("\u274C Invalid command\n");                     // Unknown command
    }
    for (int i = 0; i < allocated; free(memory[i++]));               // Cleanup on exit
    return 0;                                                         // Exit program
}