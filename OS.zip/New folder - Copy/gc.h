#ifndef GC_H
#define GC_H

#include <stdbool.h>

#define MAX_MEMORY 100

typedef struct Object {
    char name[20];       // Store object name
    bool marked;
    struct Object* next; // Reference to another object
} Object;

// Memory management functions
Object* gc_alloc(const char* name);
void gc_add_reference(Object* from, Object* to);
void gc_collect();
void gc_print_status();

#endif