// Garbage Collector Simulation with Memory Tracking
class Object {
    constructor(name) {
        this.name = name;
        this.marked = false;
        this.size = 48; // Approximate memory size per object in bytes
        this.references = [];
    }
}

// Memory tracking variables
let memory = [];
let root = null;
let totalAllocated = 0;
let totalFreed = 0;
const MAX_MEMORY = 1024; // 1KB simulated memory limit

// DOM Elements
const objectNameInput = document.getElementById('objectName');
const fromObjectSelect = document.getElementById('fromObject');
const toObjectSelect = document.getElementById('toObject');
const rootObjectSelect = document.getElementById('rootObject');
const memoryView = document.getElementById('memoryView');
const log = document.getElementById('log');
const allocatedDisplay = document.getElementById('allocated');
const activeDisplay = document.getElementById('active');
const freedDisplay = document.getElementById('freed');
const memoryProgress = document.getElementById('memoryProgress');

// Update memory metrics display
function updateMetrics() {
    const activeMemory = totalAllocated - totalFreed;
    const usagePercentage = (activeMemory / MAX_MEMORY) * 100;
    
    allocatedDisplay.textContent = `${totalAllocated} bytes`;
    activeDisplay.textContent = `${activeMemory} bytes`;
    freedDisplay.textContent = `${totalFreed} bytes`;
    memoryProgress.style.width = `${usagePercentage}%`;
    
    // Change progress bar color based on usage
    if (usagePercentage > 90) {
        memoryProgress.style.backgroundColor = '#e74c3c'; // Red
    } else if (usagePercentage > 70) {
        memoryProgress.style.backgroundColor = '#f39c12'; // Orange
    } else {
        memoryProgress.style.backgroundColor = '#27ae60'; // Green
    }
}

// Add log entry
function addLog(message) {
    const entry = document.createElement('div');
    entry.className = 'log-entry';
    entry.textContent = message;
    log.appendChild(entry);
    log.scrollTop = log.scrollHeight;
}

// Update dropdown menus
function updateSelects() {
    fromObjectSelect.innerHTML = '';
    toObjectSelect.innerHTML = '';
    rootObjectSelect.innerHTML = '';
    
    memory.forEach(obj => {
        const option = document.createElement('option');
        option.value = obj.name;
        option.textContent = obj.name;
        
        fromObjectSelect.appendChild(option.cloneNode(true));
        toObjectSelect.appendChild(option.cloneNode(true));
        rootObjectSelect.appendChild(option.cloneNode(true));
    });
}

// Render memory visualization
function renderMemory() {
    memoryView.innerHTML = '';
    
    // Show memory usage summary
    const summary = document.createElement('div');
    summary.style.marginBottom = '20px';
    summary.innerHTML = `
        <strong>Memory Usage:</strong> 
        ${totalAllocated - totalFreed} bytes active / 
        ${totalAllocated} bytes allocated
    `;
    memoryView.appendChild(summary);
    
    // Show root indicator
    if (root) {
        const rootElement = document.createElement('div');
        rootElement.textContent = `Root → ${root.name}`;
        rootElement.style.fontWeight = 'bold';
        rootElement.style.marginBottom = '10px';
        memoryView.appendChild(rootElement);
    }
    
    // Show all objects
    memory.forEach(obj => {
        const objElement = document.createElement('div');
        objElement.className = `object ${obj.marked ? 'marked' : ''} ${obj === root ? 'root' : ''}`;
        objElement.textContent = `${obj.name} (${obj.size} bytes)`;
        
        // Show references
        if (obj.references.length > 0) {
            const refsElement = document.createElement('div');
            refsElement.style.marginLeft = '20px';
            refsElement.style.marginTop = '5px';
            
            obj.references.forEach(ref => {
                const refElement = document.createElement('div');
                refElement.textContent = `→ ${ref.name}`;
                refsElement.appendChild(refElement);
            });
            
            objElement.appendChild(refsElement);
        }
        
        memoryView.appendChild(objElement);
    });
}

// Create new object
function createObject() {
    const name = objectNameInput.value.trim();
    if (!name) {
        addLog("❌ Please enter an object name");
        return;
    }
    
    if (memory.some(obj => obj.name === name)) {
        addLog(`❌ Object '${name}' already exists`);
        return;
    }
    
    if (totalAllocated - totalFreed + 48 > MAX_MEMORY) {
        addLog("⚠️ Memory limit reached! Running GC...");
        runGC();
        if (totalAllocated - totalFreed + 48 > MAX_MEMORY) {
            addLog("❌ GC couldn't free enough memory");
            return;
        }
    }
    
    const obj = new Object(name);
    memory.push(obj);
    totalAllocated += obj.size;
    addLog(`✅ Created object '${name}' (${obj.size} bytes)`);
    objectNameInput.value = '';
    
    updateMetrics();
    updateSelects();
    renderMemory();
}

// Create reference between objects
function createReference() {
    const fromName = fromObjectSelect.value;
    const toName = toObjectSelect.value;
    
    if (!fromName || !toName) {
        addLog("❌ Please select both objects");
        return;
    }
    
    const fromObj = memory.find(obj => obj.name === fromName);
    const toObj = memory.find(obj => obj.name === toName);
    
    if (fromObj.references.includes(toObj)) {
        addLog(`❌ Reference from '${fromName}' to '${toName}' already exists`);
        return;
    }
    
    fromObj.references.push(toObj);
    addLog(`🔗 Created reference: ${fromName} → ${toName}`);
    
    renderMemory();
}

// Set root object
function setRoot() {
    const name = rootObjectSelect.value;
    if (!name) {
        addLog("❌ Please select an object");
        return;
    }
    
    root = memory.find(obj => obj.name === name);
    addLog(`⭐ Set root to '${name}'`);
    
    renderMemory();
}

// Mark phase
function mark(obj) {
    if (!obj || obj.marked) return;
    
    obj.marked = true;
    addLog(`  ✓ Marking '${obj.name}'`);
    
    // Recursively mark references
    obj.references.forEach(ref => mark(ref));
}

// Sweep phase
function sweep() {
    let freedThisCycle = 0;
    const newMemory = [];
    
    memory.forEach(obj => {
        if (!obj.marked) {
            freedThisCycle += obj.size;
            totalFreed += obj.size;
            addLog(`🗑️ Deleted '${obj.name}' (${obj.size} bytes freed)`);
        } else {
            obj.marked = false;
            newMemory.push(obj);
        }
    });
    
    memory = newMemory;
    addLog(`♻️ Freed ${freedThisCycle} bytes in this GC cycle`);
}

// Run garbage collection
function runGC() {
    addLog("\n🔍 Starting Garbage Collection:");
    
    // Mark phase
    if (root) mark(root);
    else addLog("  No root object set - nothing is reachable");
    
    // Sweep phase
    sweep();
    
    updateMetrics();
    updateSelects();
    renderMemory();
}

// Initialize
updateMetrics();
updateSelects();
renderMemory();
addLog("Ready to demonstrate garbage collection!");